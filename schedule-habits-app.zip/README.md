# Schedule & Daily Habits App

A full-stack calendar and habit tracking application.

## Project Structure
```
project/
├── backend/          # FastAPI + PostgreSQL
└── frontend/         # React + TypeScript + Tailwind
```

## Backend Setup

1. Create virtual environment:
```bash
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Copy and fill in environment variables:
```bash
cp .env.example .env
# Edit .env with your actual values
```

4. **Fix database error**: Set correct DATABASE_URL in .env:
```
DATABASE_URL=postgresql://neondb_owner:YOUR_ACTUAL_PASSWORD@YOUR_NEON_HOST/neondb
```
Get this from your Neon dashboard → Connection Details.

5. Run the server:
```bash
uvicorn main:app --reload
```

## Frontend Setup

1. Install dependencies:
```bash
cd frontend
npm install
# or: pnpm install
```

2. Create .env file:
```bash
cp .env.example .env
# Set VITE_BACKEND_URL to your backend URL
```

3. Run the dev server:
```bash
npm run dev
```

## Key Features
- Smart Calendar with multi-calendar system support (Gregorian, Nepali BS, Persian, Thai, Indian, Ethiopian)
- Daily habit tracking (meals, water, exercise, meditation, sleep)
- Calendar sharing via unique tokens
- OIDC/SSO authentication
- Browser push notifications for event reminders
