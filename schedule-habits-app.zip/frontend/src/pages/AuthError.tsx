import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { AlertCircle } from 'lucide-react';
export default function AuthErrorPage() {
  const [searchParams] = useSearchParams();
  const [countdown, setCountdown] = useState(3);
  const errorMessage = searchParams.get('msg') || 'Sorry, your authentication information is invalid or has expired';
  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) { clearInterval(timer); window.location.href = '/'; return 0; }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-gray-50 to-blue-50 p-6 text-center">
      <div className="space-y-6 max-w-md">
        <AlertCircle className="h-12 w-12 text-red-500 mx-auto" />
        <h1 className="text-2xl font-bold text-gray-800">Authentication Error</h1>
        <p className="text-base text-muted-foreground">{errorMessage}</p>
        <p className="text-sm text-gray-500">Redirecting in <span className="text-blue-600 font-semibold">{countdown}</span> seconds</p>
        <Button onClick={() => window.location.href = '/'}>Return to Home</Button>
      </div>
    </div>
  );
}
