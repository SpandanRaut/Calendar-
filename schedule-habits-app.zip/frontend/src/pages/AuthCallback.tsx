import { useEffect } from 'react';
import { createClient } from '@metagptx/web-sdk';
const client = createClient();
export default function AuthCallback() {
  useEffect(() => {
    client.auth.login().then(() => { window.location.href = '/'; });
  }, []);
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-50">
      <div className="text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
        <p className="text-lg text-gray-600">Completing login...</p>
      </div>
    </div>
  );
}
