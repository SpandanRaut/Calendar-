import { createClient } from '@metagptx/web-sdk';

export const client = createClient({
  baseURL: import.meta.env.VITE_BACKEND_URL || '',
});

export const eventsApi = {
  async getAll() {
    const response = await client.entities.events.query({ query: {}, sort: '-created_at', limit: 100 });
    return response.data.items;
  },
  async create(data: any) {
    const response = await client.entities.events.create({ data });
    return response.data;
  },
  async update(id: number, data: any) {
    const response = await client.entities.events.update({ id: id.toString(), data });
    return response.data;
  },
  async delete(id: number) {
    await client.entities.events.delete({ id: id.toString() });
  },
};

export const dailyLogsApi = {
  async getByDate(date: string) {
    const response = await client.entities.daily_logs.query({ query: { date }, limit: 1 });
    return response.data.items[0] || null;
  },
  async create(data: any) {
    const response = await client.entities.daily_logs.create({ data });
    return response.data;
  },
  async update(id: number, data: any) {
    const response = await client.entities.daily_logs.update({ id: id.toString(), data });
    return response.data;
  },
};

export const userProfileApi = {
  async get() {
    const response = await client.entities.user_profiles.query({ query: {}, limit: 1 });
    return response.data.items[0] || null;
  },
  async create(data: any) {
    const response = await client.entities.user_profiles.create({ data });
    return response.data;
  },
  async update(id: number, data: any) {
    const response = await client.entities.user_profiles.update({ id: id.toString(), data });
    return response.data;
  },
};
