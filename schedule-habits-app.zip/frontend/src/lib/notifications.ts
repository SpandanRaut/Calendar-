export const requestNotificationPermission = async (): Promise<boolean> => {
  if (!('Notification' in window)) return false;
  if (Notification.permission === 'granted') return true;
  if (Notification.permission !== 'denied') {
    const permission = await Notification.requestPermission();
    return permission === 'granted';
  }
  return false;
};

export const showNotification = (title: string, body: string): void => {
  if (Notification.permission === 'granted') {
    new Notification(title, { body });
  }
};

export const scheduleReminder = (eventTitle: string, eventDate: string, eventTime: string, reminderMinutes: number): void => {
  const eventDateTime = new Date(`${eventDate}T${eventTime}`);
  const reminderTime = new Date(eventDateTime.getTime() - reminderMinutes * 60000);
  const now = new Date();
  if (reminderTime > now) {
    const timeout = reminderTime.getTime() - now.getTime();
    setTimeout(() => {
      showNotification('Upcoming Event Reminder', `"${eventTitle}" starts in ${reminderMinutes} minutes`);
    }, timeout);
  }
};
