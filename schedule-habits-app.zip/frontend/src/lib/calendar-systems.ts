// Calendar system utilities
export interface CalendarSystem {
  id: string;
  name: string;
  country: string;
  description: string;
}

export const CALENDAR_SYSTEMS: CalendarSystem[] = [
  { id: 'gregorian', name: 'Gregorian Calendar', country: 'International', description: 'Standard international calendar (January-December)' },
  { id: 'nepali', name: 'Bikram Sambat (BS)', country: 'Nepal', description: 'Nepali calendar system' },
  { id: 'indian', name: 'Indian National Calendar', country: 'India', description: 'Saka calendar (Chaitra-Phalguna)' },
  { id: 'persian', name: 'Persian Calendar', country: 'Iran', description: 'Solar Hijri calendar' },
  { id: 'thai', name: 'Thai Solar Calendar', country: 'Thailand', description: 'Buddhist Era calendar' },
  { id: 'ethiopian', name: 'Ethiopian Calendar', country: 'Ethiopia', description: "Ge'ez calendar" },
];

export const COUNTRIES = [
  { code: 'US', name: 'United States', defaultCalendar: 'gregorian' },
  { code: 'GB', name: 'United Kingdom', defaultCalendar: 'gregorian' },
  { code: 'NP', name: 'Nepal', defaultCalendar: 'nepali' },
  { code: 'IN', name: 'India', defaultCalendar: 'indian' },
  { code: 'IR', name: 'Iran', defaultCalendar: 'persian' },
  { code: 'TH', name: 'Thailand', defaultCalendar: 'thai' },
  { code: 'ET', name: 'Ethiopia', defaultCalendar: 'ethiopian' },
  { code: 'CN', name: 'China', defaultCalendar: 'gregorian' },
  { code: 'JP', name: 'Japan', defaultCalendar: 'gregorian' },
  { code: 'AU', name: 'Australia', defaultCalendar: 'gregorian' },
  { code: 'CA', name: 'Canada', defaultCalendar: 'gregorian' },
  { code: 'DE', name: 'Germany', defaultCalendar: 'gregorian' },
  { code: 'FR', name: 'France', defaultCalendar: 'gregorian' },
  { code: 'BR', name: 'Brazil', defaultCalendar: 'gregorian' },
  { code: 'PK', name: 'Pakistan', defaultCalendar: 'gregorian' },
  { code: 'BD', name: 'Bangladesh', defaultCalendar: 'gregorian' },
  { code: 'SA', name: 'Saudi Arabia', defaultCalendar: 'gregorian' },
  { code: 'AE', name: 'United Arab Emirates', defaultCalendar: 'gregorian' },
];

const nepaliMonths = ['Baishakh','Jestha','Ashadh','Shrawan','Bhadra','Ashwin','Kartik','Mangsir','Poush','Magh','Falgun','Chaitra'];
const indianMonths = ['Chaitra','Vaisakha','Jyaistha','Asadha','Sravana','Bhadra','Asvina','Kartika','Agrahayana','Pausa','Magha','Phalguna'];
const persianMonths = ['Farvardin','Ordibehesht','Khordad','Tir','Mordad','Shahrivar','Mehr','Aban','Azar','Dey','Bahman','Esfand'];
const thaiMonths = ['January','February','March','April','May','June','July','August','September','October','November','December'];
const ethiopianMonths = ['Meskerem','Tikimt','Hidar','Tahsas','Tir','Yekatit','Megabit','Miazia','Ginbot','Sene','Hamle','Nehase','Pagumen'];

export function getMonthNames(calendarSystem: string): string[] {
  switch (calendarSystem) {
    case 'nepali': return nepaliMonths;
    case 'indian': return indianMonths;
    case 'persian': return persianMonths;
    case 'thai': return thaiMonths;
    case 'ethiopian': return ethiopianMonths;
    default: return ['January','February','March','April','May','June','July','August','September','October','November','December'];
  }
}

export function convertToCalendarSystem(gregorianDate: Date, calendarSystem: string): { year: number; month: number; day: number; monthName: string } {
  const year = gregorianDate.getFullYear();
  const month = gregorianDate.getMonth();
  const day = gregorianDate.getDate();
  switch (calendarSystem) {
    case 'nepali': return { year: year + 57, month, day, monthName: getMonthNames('nepali')[month] };
    case 'indian': { let m = month - 2; if (m < 0) m += 12; return { year: year - 78, month: m, day, monthName: getMonthNames('indian')[m] }; }
    case 'persian': { let m = month - 2; if (m < 0) m += 12; return { year: year - 621, month: m, day, monthName: getMonthNames('persian')[m] }; }
    case 'thai': return { year: year + 543, month, day, monthName: getMonthNames('thai')[month] };
    case 'ethiopian': return { year: year - 7, month, day, monthName: getMonthNames('ethiopian')[month] };
    default: return { year, month, day, monthName: getMonthNames('gregorian')[month] };
  }
}

export function getCalendarSystemInfo(calendarSystem: string): CalendarSystem | undefined {
  return CALENDAR_SYSTEMS.find(cs => cs.id === calendarSystem);
}

export function getDefaultCalendarForCountry(countryCode: string): string {
  const country = COUNTRIES.find(c => c.code === countryCode);
  return country?.defaultCalendar || 'gregorian';
}
