export interface Event {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  category: 'work' | 'personal' | 'health' | 'other';
  reminder?: number;
  completed: boolean;
  createdAt: string;
}
export type ReminderTime = 5 | 15 | 60 | 1440;
export interface DailyLog {
  date: string;
  breakfast: boolean;
  lunch: boolean;
  dinner: boolean;
  waterGlasses: number;
  exerciseMinutes: number;
  meditationMinutes: number;
  sleepHours: number;
}
