from core.database import Base
from sqlalchemy import Column, Integer, String

class Calendar_shares(Base):
    __tablename__ = "calendar_shares"
    __table_args__ = {"extend_existing": True}
    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    user_id = Column(String, nullable=False)
    share_type = Column(String, nullable=False)
    share_token = Column(String, nullable=False)
    event_ids = Column(String, nullable=True)
    expires_at = Column(String, nullable=True)
    created_at = Column(String, nullable=False)
