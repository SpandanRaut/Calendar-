from core.database import Base
from sqlalchemy import Boolean, Column, DateTime, Float, Integer, String

class Daily_logs(Base):
    __tablename__ = "daily_logs"
    __table_args__ = {"extend_existing": True}
    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    user_id = Column(String, nullable=False)
    date = Column(String, nullable=False)
    breakfast = Column(Boolean, nullable=True)
    lunch = Column(Boolean, nullable=True)
    dinner = Column(Boolean, nullable=True)
    water_glasses = Column(Integer, nullable=True)
    exercise_minutes = Column(Integer, nullable=True)
    meditation_minutes = Column(Integer, nullable=True)
    sleep_hours = Column(Float, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=True)
