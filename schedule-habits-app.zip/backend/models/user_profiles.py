from core.database import Base
from sqlalchemy import Boolean, Column, DateTime, Integer, String

class User_profiles(Base):
    __tablename__ = "user_profiles"
    __table_args__ = {"extend_existing": True}
    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    user_id = Column(String, nullable=False)
    full_name = Column(String, nullable=True)
    avatar_url = Column(String, nullable=True)
    bio = Column(String, nullable=True)
    country_code = Column(String, nullable=True)
    calendar_system = Column(String, nullable=True)
    email_notifications = Column(Boolean, nullable=True)
    push_notifications = Column(Boolean, nullable=True)
    reminder_notifications = Column(Boolean, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=True)
