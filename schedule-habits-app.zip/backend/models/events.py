from core.database import Base
from sqlalchemy import Boolean, Column, DateTime, Integer, String

class Events(Base):
    __tablename__ = "events"
    __table_args__ = {"extend_existing": True}
    id = Column(Integer, primary_key=True, index=True, autoincrement=True, nullable=False)
    user_id = Column(String, nullable=False)
    title = Column(String, nullable=False)
    description = Column(String, nullable=True)
    date = Column(String, nullable=False)
    time = Column(String, nullable=False)
    category = Column(String, nullable=True)
    reminder_minutes = Column(Integer, nullable=True)
    completed = Column(Boolean, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=True)
