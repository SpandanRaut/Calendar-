import logging
import os
from typing import Any
from pydantic_settings import BaseSettings

logger = logging.getLogger(__name__)

class Settings(BaseSettings):
    app_name: str = "Schedule App"
    debug: bool = False
    version: str = "1.0.0"
    host: str = "0.0.0.0"
    port: int = 8000
    is_lambda: bool = False
    environment: str = "development"

    @property
    def backend_url(self) -> str:
        display_host = "127.0.0.1" if self.host == "0.0.0.0" else self.host
        return os.environ.get("PYTHON_BACKEND_URL", f"http://{display_host}:{self.port}")

    class Config:
        case_sensitive = False
        extra = "ignore"

    def __getattr__(self, name: str) -> Any:
        env_var_name = name.upper()
        if env_var_name in os.environ:
            value = os.environ[env_var_name]
            self.__dict__[name] = value
            return value
        raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{name}'")

settings = Settings()
